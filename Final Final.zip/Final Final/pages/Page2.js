import React from 'react'
// import '../App.css'

function Page2(){
    return (
        <div className="App">
            <h2>Page 2</h2>
        </div>
    );
}

export default Page2